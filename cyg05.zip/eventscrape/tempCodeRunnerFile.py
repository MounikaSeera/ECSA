sv

    # # File path where you want to save the CSV file
    # csv_file_path = 'output.csv'

    # # Writing data into the CSV file
    # with open(csv_file_path, 'w', newline='') as csvfile:
    #     writer = csv.writer(csvfile)
        
    #     # Write the header (field names)
    #     # writer.writerow(['Name', 'Rating'])
        
    #     # Write the content
    #     for key, value in dic.items():
    #         writer.writerow([key])
    #         writer.writerow([value])