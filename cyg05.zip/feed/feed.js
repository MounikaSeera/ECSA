

// document.getElementById("postButton").addEventListener("click", function(event) {
//     const checkedRating = document.querySelector('input[name="rate"]:checked');
//     if (checkedRating) {
//       const ratingValue = checkedRating.id.split("-")[1];
//       console.log("Rating given:", ratingValue);
//     } else {
//       console.log("No rating selected.");
//     }
//     event.preventDefault(); // Prevent the form submission
//   });
// const firebaseConfig = {
//     apiKey: "AIzaSyCnws974XAgmZrrSUlQxU9F9bYyMbrXw3o",
//     authDomain: "feedback-4d371.firebaseapp.com",
//     databaseURL: "https://feedback-4d371-default-rtdb.firebaseio.com",
//     projectId: "feedback-4d371",
//     storageBucket: "feedback-4d371.appspot.com",
//     messagingSenderId: "1001301659367",
//     appId: "1:1001301659367:web:2f7ef953537df017d3dc42"
//   };

//   firebase.initializeApp(firebaseConfig);
//   const feeddb = firebase.database().ref('feedback');


// btn.addEventListener("click", function(event) {
//   event.preventDefault(); // Prevent form submission

//   const textareaContent = document.getElementById("textareadata").value;
//   console.log("Textarea content:", textareaContent);

//   // Hide the widget and display the post message
//   widget.style.display = "none";
//   post.style.display = "block";
// });

// editBtn.onclick = () => {
//   widget.style.display = "block";
//   post.style.display = "none";
// };
// const btn = document.querySelector("button");
//       const post = document.querySelector(".post");
//       const widget = document.querySelector(".star-widget");
//       const editBtn = document.querySelector(".edit");
//       btn.onclick = ()=>{
//         widget.style.display = "none";
//         post.style.display = "block";
//         editBtn.onclick = ()=>{
//           widget.style.display = "block";
//           post.style.display = "none";
//         }
//         return false;
//       }

const btn = document.querySelector("button");
const post = document.querySelector(".post");
const widget = document.querySelector(".star-widget");
const editBtn = document.querySelector(".edit");

document.getElementById('feedform').addEventListener("submit", submitfeedback);

function submitfeedback(e) {
    e.preventDefault();
    var name = getElementval("textareadata");
    console.log(name);
    s(name);

    // Add a "Thank you" message
    const thankYouMessage = document.createElement("div");
    thankYouMessage.textContent = "Thank you for your feedback!";
    thankYouMessage.classList.add("thank-you-message");

    // Insert the message after the post div
    post.parentNode.insertBefore(thankYouMessage, post.nextSibling);

    // Hide the widget and display the post message
    widget.style.display = "none";
    post.style.display = "block";

    // Reset the form (optional)
    document.getElementById('feedform').reset();
}

const s =  (f) =>{
    var form = formdb.push();
    form.set({
        feed : f ,
    })
};

const getElementval = (id) => {
    return document.getElementById(id).value;
};


 